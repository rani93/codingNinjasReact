import Input from "./Components/InputWithFunction";

function App() {
  return (
    <>
      <Input />

     
    </>
  );
}

export default App;
