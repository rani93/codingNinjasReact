import React from "react";
import TimerOne from "./Components/Timer/TimerOne.js";

class App extends React.Component {

  render() {
    return (
      <>
        <TimerOne />
      </>
    );
  }
}

export default App;
